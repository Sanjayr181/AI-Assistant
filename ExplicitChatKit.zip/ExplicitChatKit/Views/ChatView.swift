import SwiftUI

struct ChatView: View {
    @EnvironmentObject var vm: ChatViewModel
    @FocusState private var focused: Bool
    
    var body: some View {
        VStack(spacing: 0) {
            header
            ScrollViewReader { proxy in
                ScrollView {
                    LazyVStack(spacing: 12) {
                        ForEach(vm.messages) { msg in
                            MessageRow(message: msg)
                                .id(msg.id)
                        }
                        if vm.isSending {
                            ProgressView().padding(.vertical, 8)
                        }
                        if let error = vm.errorText {
                            Text(error).font(.footnote).foregroundStyle(.red).padding(.vertical, 8)
                        }
                    }.padding(.horizontal)
                }
                .onChange(of: vm.messages.count) { _ in
                    if let last = vm.messages.last { withAnimation { proxy.scrollTo(last.id, anchor: .bottom) } }
                }
            }
            inputBar
        }
    }
    
    var header: some View {
        VStack(spacing: 8) {
            HStack {
                PersonaPickerView(selected: $vm.selectedPersona, personas: $vm.personas)
                Spacer()
                Toggle("Explicit", isOn: $vm.isExplicit)
                    .toggleStyle(.switch)
                    .labelsHidden()
                Text(vm.isExplicit ? "Explicit On" : "Explicit Off")
                    .font(.footnote)
            }
            .padding([.horizontal, .top])
            Divider()
        }
    }
    
    var inputBar: some View {
        HStack(spacing: 8) {
            TextField("Say something…", text: $vm.input, axis: .vertical)
                .textFieldStyle(.roundedBorder)
                .focused($focused)
                .onSubmit { vm.send() }
            Button(action: vm.send) {
                Image(systemName: "paperplane.fill")
            }
            .disabled(vm.isSending || vm.input.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
        }
        .padding()
    }
}
