import Foundation

struct LLMConfig {
    var apiBaseURL: URL
    var apiKey: String
    var model: String
    var temperature: Double = 0.8
    var maxTokens: Int = 512
    
    static func fromPlist() -> LLMConfig {
        let url = Bundle.main.url(forResource: "Config", withExtension: "plist") ?? Bundle.main.url(forResource: "SampleConfig", withExtension: "plist")!
        let data = try! Data(contentsOf: url)
        let dict = try! PropertyListSerialization.propertyList(from: data, options: [], format: nil) as! [String: Any]
        let base = (dict["API_BASE_URL"] as? String).flatMap(URL.init(string:)) ?? URL(string: "http://127.0.0.1:11434/v1")!
        let key = (dict["API_KEY"] as? String) ?? "ollama"
        let model = (dict["MODEL"] as? String) ?? "llama3.1"
        let temp = (dict["TEMPERATURE"] as? Double) ?? 0.8
        let maxToks = (dict["MAX_TOKENS"] as? Int) ?? 512
        return LLMConfig(apiBaseURL: base, apiKey: key, model: model, temperature: temp, maxTokens: maxToks)
    }
}

final class LLMClient {
    private let config: LLMConfig
    init(config: LLMConfig = .fromPlist()) {
        self.config = config
    }
    
    struct ChatCompletionRequest: Encodable {
        struct Message: Encodable {
            let role: String
            let content: String
        }
        let model: String
        let messages: [Message]
        let temperature: Double
        let max_tokens: Int
        let stream: Bool = false
    }
    
    struct ChatCompletionResponse: Decodable {
        struct Choice: Decodable {
            struct Message: Decodable {
                let role: String
                let content: String?
            }
            let message: Message
        }
        let choices: [Choice]
    }
    
    func complete(messages: [ChatMessage], persona: Persona, explicitMode: Bool) async throws -> String {
        // Build system prompt
        let safety = """
        SAFETY RULES (hard limits): No minors. No sexual violence. No bestiality. No illegal content. Respect consent.
        """
        let tone = explicitMode
        ? "You may use profanity and adult/NSFW language when the user invites it. Keep it between consenting adults. Avoid explicit pornographic step-by-step acts; imply when needed."
        : "Avoid profanity or NSFW content. Keep language safe-for-work and supportive."
        
        let systemPrompt = """
        You are \(persona.name), \(persona.description)
        Style guide: \(persona.style)
        \(tone)
        \(safety)
        When asked to roleplay, stay in character. If the user crosses hard limits, gently refuse and suggest safer alternatives.
        """
        
        let wireMsgs: [ChatCompletionRequest.Message] =
            [ChatCompletionRequest.Message(role: "system", content: systemPrompt)]
            + messages.map { .init(role: $0.role.rawValue, content: $0.content) }
        
        let req = ChatCompletionRequest(model: config.model, messages: wireMsgs, temperature: config.temperature, max_tokens: config.maxTokens)
        
        var url = config.apiBaseURL
        url.append(path: "/v1/chat/completions")
        
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.addValue("Bearer \(config.apiKey)", forHTTPHeaderField: "Authorization")
        request.httpBody = try JSONEncoder().encode(req)
        
        let (data, resp) = try await URLSession.shared.data(for: request)
        guard let http = resp as? HTTPURLResponse, (200..<300).contains(http.statusCode) else {
            let body = String(data: data, encoding: .utf8) ?? "<?>"
            throw NSError(domain: "LLMClient", code: (resp as? HTTPURLResponse)?.statusCode ?? -1, userInfo: [NSLocalizedDescriptionKey: "Bad response: \(resp). Body: \(body)"])
        }
        let decoded = try JSONDecoder().decode(ChatCompletionResponse.self, from: data)
        return decoded.choices.first?.message.content ?? ""
    }
}
