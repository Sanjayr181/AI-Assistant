import Foundation

struct Persona: Identifiable, Codable, Equatable {
    let id: UUID
    var name: String
    var description: String
    var style: String
    
    init(id: UUID = UUID(), name: String, description: String, style: String) {
        self.id = id
        self.name = name
        self.description = description
        self.style = style
    }
    
    static var defaults: [Persona] = [
        .init(name: "Nova", description: "Witty, flirty, playful chatbot for casual banter.", style: "Light sarcasm, playful teasing, internet slang allowed. Keep replies concise unless asked."),
        .init(name: "Sage", description: "Supportive confidant for deeper talks.", style: "Warm, empathetic, reflective listening. Avoid judgment. Ask thoughtful follow-ups."),
        .init(name: "Muse", description: "Creative roleplay and story building.", style: "Vivid descriptions, show-don't-tell. Keeps narrative moving. Honors user world-building.")
    ]
}
