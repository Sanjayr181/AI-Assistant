# ExplicitChatKit (SwiftUI, iOS)
A tiny, local-first Character.AI–style starter you can run on iOS. It supports any **OpenAI-compatible** API (OpenAI, local **Ollama** at `http://localhost:11434/v1`, Together, OpenRouter, etc.).

> ⚠️ Content & provider rules: You control what the AI says. If you enable **Explicit Mode**, the system prompt allows coarse/NSFW language between consenting adults, while still blocking minors, sexual violence, or illegal content. **Your API provider may still block explicit content**; local models via **Ollama** usually give you more freedom.

## Quick start
1. **Create a new Xcode project** → iOS App → SwiftUI, name it `ExplicitChatKitApp` (or anything).
2. In Finder, copy the files from this folder into your new project folder. In Xcode, drag them into the project (tick *Copy items if needed*).
3. Create a `Config.plist` in the **Config** group (or duplicate `SampleConfig.plist` and rename). Add:
   - `API_BASE_URL` (String) — e.g. `http://localhost:11434/v1` for Ollama, or `https://api.openai.com/v1`.
   - `API_KEY` (String) — for Ollama you can put anything like `ollama`.
   - `MODEL` (String) — e.g. `llama3.1` (Ollama), `gpt-4o-mini` (OpenAI), etc.
4. **Run a backend**:
   - **Ollama (recommended for explicit mode)** on your Mac: `brew install ollama && ollama serve && ollama pull llama3.1`
     - Keep it running; the iOS simulator will reach `http://127.0.0.1:11434/v1` via your Mac. Use `API_BASE_URL=http://127.0.0.1:11434/v1`.
   - **OpenAI**: use `https://api.openai.com/v1` with your key (note: explicit sexual content may be blocked per policy).
5. Build & run. Tap the persona chip to edit persona style. Toggle **Explicit Mode** to allow profanity/adult tone between consenting adults.

## Notes
- Uses non-streaming completions for simplicity; you can switch to SSE later.
- Persona definitions live in code and are user-editable in-app.
- Stores nothing remotely; no analytics.
- iOS 16+ target by default; adjust as needed.

## Safety defaults (non-negotiable)
- **No minors. No sexual violence. No bestiality. No illegal content.**
- When **Explicit Mode** is off, the assistant avoids NSFW content and profanity.

---
Made for personal use and learning.
