import SwiftUI

@main
struct ExplicitAIApp: App {
    @StateObject private var vm = ChatViewModel()
    
    var body: some Scene {
        WindowGroup {
            ChatView()
                .environmentObject(vm)
        }
    }
}
