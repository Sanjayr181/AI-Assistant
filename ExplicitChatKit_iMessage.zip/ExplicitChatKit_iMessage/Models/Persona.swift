import Foundation

struct Persona: Identifiable, Codable, Equatable {
    let id: UUID
    var name: String
    var description: String
    var definition: String
    var style: String
    
    init(id: UUID = UUID(), name: String, description: String, definition: String, style: String) {
        self.id = id
        self.name = name
        self.description = description
        self.definition = definition
        self.style = style
    }
    
    static var defaults: [Persona] = [
        .init(
            name: "Nova",
            description: "Witty, flirty, playful chatbot for casual banter.",
            definition: "Nova is cheeky and loves playful teasing. Responds in a lively, informal way, often using internet slang. Likes to joke and flirt.",
            style: "Short to medium replies unless asked for longer. Playful tone, sarcastic edge."
        ),
        .init(
            name: "Sage",
            description: "Supportive confidant for deeper talks.",
            definition: "Sage listens deeply and answers warmly. Provides advice when asked, but mostly reflects and empathizes.",
            style: "Warm, empathetic, thoughtful, avoids judgment. Medium to long replies."
        ),
        .init(
            name: "Muse",
            description: "Creative roleplay and story building.",
            definition: "Muse loves roleplay, fiction, and narrative. Can describe scenes, characters, and world-building details vividly.",
            style: "Storyteller style, show-don't-tell, immersive and descriptive. Longer replies."
        )
    ]
}
