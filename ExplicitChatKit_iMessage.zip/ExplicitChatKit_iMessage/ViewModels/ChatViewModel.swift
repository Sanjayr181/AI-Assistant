import Foundation
import SwiftUI

@MainActor
final class ChatViewModel: ObservableObject {
    @Published var messages: [ChatMessage] = []
    @Published var personas: [Persona] = Persona.defaults
    @Published var selectedPersona: Persona = Persona.defaults.first!
    @Published var input: String = ""
    @Published var isExplicit: Bool = false
    @Published var isSending: Bool = false
    @Published var errorText: String? = nil
    
    private let client = LLMClient()
    
    func send() {
        let text = input.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !text.isEmpty else { return }
        input = ""
        messages.append(.init(role: .user, content: text))
        Task { await respondStream() }
    }
    
    func respondStream() async {
        isSending = true
        errorText = nil
        do {
            var replyMsg = ChatMessage(role: .assistant, content: "")
            messages.append(replyMsg)
            let idx = messages.count - 1
            for try await chunk in client.stream(messages: messages, persona: selectedPersona, explicitMode: isExplicit) {
                messages[idx].content.append(chunk)
            }
        } catch {
            errorText = error.localizedDescription
        }
        isSending = false
    }
    
    func resetChat() {
        messages.removeAll()
        errorText = nil
    }
}
