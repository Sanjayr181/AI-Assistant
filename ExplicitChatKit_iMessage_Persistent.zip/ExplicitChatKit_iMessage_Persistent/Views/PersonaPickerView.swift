
import SwiftUI

struct PersonaPickerView: View {
    @Binding var selected: Persona
    @Binding var personas: [Persona]
    @State private var isEditing = false
    
    var body: some View {
        Menu {
            ForEach(personas) { p in
                Button(action: { selected = p }) {
                    Label(p.name, systemImage: p.id == selected.id ? "checkmark" : "person")
                }
            }
            Divider()
            Button("Edit Personas…") { isEditing = true }
        } label: {
            HStack(spacing: 6) {
                Image(systemName: "person.crop.circle")
                Text(selected.name)
            }
            .padding(.vertical, 6)
            .padding(.horizontal, 10)
            .background(Color.gray.opacity(0.15))
            .clipShape(Capsule())
        }
        .sheet(isPresented: $isEditing) {
            PersonaEditorView(selected: $selected, personas: $personas)
        }
    }
}

struct PersonaEditorView: View {
    @Binding var selected: Persona
    @Binding var personas: [Persona]
    @Environment(\.dismiss) var dismiss
    
    @State private var draft: Persona = Persona.defaults.first!
    
    var body: some View {
        NavigationView {
            List {
                ForEach(personas) { p in
                    VStack(alignment: .leading, spacing: 6) {
                        HStack {
                            Text(p.name).font(.headline)
                            Spacer()
                            if p.id == selected.id { Image(systemName: "checkmark.circle.fill") }
                        }
                        Text(p.description).font(.subheadline)
                        Text("Style: \(p.style)").font(.caption).foregroundStyle(.secondary)
                    }
                    .contentShape(Rectangle())
                    .onTapGesture { selected = p }
                }
                .onDelete { idx in personas.remove(atOffsets: idx) }
            }
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) { Button("Close") { dismiss() } }
                ToolbarItem(placement: .navigationBarTrailing) { Button("Add") { addPersona() } }
            }
            .navigationTitle("Personas")
        }
    }
    
    func addPersona() {
        draft = Persona(name: "New Persona", description: "Describe the persona.", definition: "Definition text", style: "Write how they talk.")
        personas.append(draft)
    }
}
