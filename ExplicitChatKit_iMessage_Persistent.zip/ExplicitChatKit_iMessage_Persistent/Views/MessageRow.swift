import SwiftUI

struct MessageRow: View {
    let message: ChatMessage
    var isUser: Bool { message.role == .user }
    
    var body: some View {
        HStack(alignment: .bottom, spacing: 8) {
            if isUser {
                Spacer(minLength: 50)
                bubble
                avatar(system: "person.crop.circle.fill", color: .blue)
            } else {
                avatar(system: "sparkles", color: .gray)
                bubble
                Spacer(minLength: 50)
            }
        }
        .padding(.vertical, 2)
    }
    
    @ViewBuilder
    var bubble: some View {
        Text(message.content)
            .padding(12)
            .background(isUser ? Color.blue : Color.gray.opacity(0.2))
            .foregroundColor(isUser ? .white : .primary)
            .clipShape(RoundedRectangle(cornerRadius: 20, style: .continuous))
            .shadow(radius: 1, y: 1)
    }
    
    func avatar(system: String, color: Color) -> some View {
        Image(systemName: system)
            .font(.system(size: 22))
            .padding(6)
            .background(color.opacity(0.3))
            .clipShape(Circle())
    }
}
