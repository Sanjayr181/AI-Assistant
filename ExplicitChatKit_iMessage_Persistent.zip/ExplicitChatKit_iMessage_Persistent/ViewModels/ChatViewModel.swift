import Foundation
import SwiftUI

@MainActor
final class ChatViewModel: ObservableObject {
    @Published var messages: [ChatMessage] = []
    @Published var personas: [Persona] = Persona.defaults {
        didSet { savePersonas() }
    }
    @Published var selectedPersona: Persona = Persona.defaults.first! {
        didSet { loadMessagesForSelectedPersona() }
    }
    @Published var input: String = ""
    @Published var isExplicit: Bool = false
    @Published var isSending: Bool = false
    @Published var errorText: String? = nil
    
    private let client = LLMClient()
    
    private var storageURL: URL {
        FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
    }
    
    init() {
        loadPersonas()
        // ensure selected persona exists in personas
        if let first = personas.first { selectedPersona = first }
        loadMessagesForSelectedPersona()
    }
    
    // MARK: - Send / Stream
    func send() {
        let text = input.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !text.isEmpty else { return }
        input = ""
        let msg = ChatMessage(role: .user, content: text)
        messages.append(msg)
        saveMessagesForSelectedPersona()
        Task { await respondStream() }
    }
    
    func respondStream() async {
        isSending = true
        errorText = nil
        do {
            // append empty assistant message to be filled by stream
            let replyMsg = ChatMessage(role: .assistant, content: "")
            messages.append(replyMsg)
            saveMessagesForSelectedPersona()
            let idx = messages.count - 1
            for try await chunk in client.stream(messages: self.messages, persona: selectedPersona, explicitMode: isExplicit) {
                messages[idx].content.append(chunk)
                saveMessagesForSelectedPersona()
            }
        } catch {
            errorText = error.localizedDescription
            saveMessagesForSelectedPersona()
        }
        isSending = false
    }
    
    // MARK: - Persistence (per persona)
    func personaFilename(_ persona: Persona) -> String {
        "chat_\(persona.id.uuidString).json"
    }
    
    func saveMessagesForSelectedPersona() {
        do {
            let url = storageURL.appendingPathComponent(personaFilename(selectedPersona))
            let data = try JSONEncoder().encode(messages)
            try data.write(to: url, options: [.atomic])
        } catch {
            print("Save messages failed:", error)
        }
    }
    
    func loadMessagesForSelectedPersona() {
        do {
            let url = storageURL.appendingPathComponent(personaFilename(selectedPersona))
            if FileManager.default.fileExists(atPath: url.path) {
                let data = try Data(contentsOf: url)
                messages = try JSONDecoder().decode([ChatMessage].self, from: data)
                return
            }
            // no file -> start with empty or a system intro
            messages = [ChatMessage(role: .system, content: "You are now chatting with \(selectedPersona.name). \(selectedPersona.description)")]
        } catch {
            print("Load messages failed:", error)
            messages = []
        }
    }
    
    // MARK: - Personas persistence
    private var personasFile: URL {
        storageURL.appendingPathComponent("personas.json")
    }
    
    func savePersonas() {
        do {
            let data = try JSONEncoder().encode(personas)
            try data.write(to: personasFile, options: [.atomic])
        } catch {
            print("Save personas failed:", error)
        }
    }
    
    func loadPersonas() {
        do {
            if FileManager.default.fileExists(atPath: personasFile.path) {
                let data = try Data(contentsOf: personasFile)
                personas = try JSONDecoder().decode([Persona].self, from: data)
            }
        } catch {
            print("Load personas failed:", error)
        }
    }
    
    func resetChat() {
        messages.removeAll()
        saveMessagesForSelectedPersona()
        errorText = nil
    }
}
