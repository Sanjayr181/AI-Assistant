import Foundation

struct ChatMessage: Identifiable, Codable, Equatable {
    enum Role: String, Codable { case user, assistant, system }
    let id: UUID
    var role: Role
    var content: String
    var timestamp: Date
    
    init(id: UUID = UUID(), role: Role, content: String, timestamp: Date = .init()) {
        self.id = id
        self.role = role
        self.content = content
        self.timestamp = timestamp
    }
}
